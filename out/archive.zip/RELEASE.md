
# Release Change Logs

`Add Release changes below`


=====================================================================
### Release-2018-02-26 (version: 2.5.20)

#### major features

1. Network Detail Screens
2. Enhanced EPG
3. Continue Watch

#### minor fixes

1. reduce live streaming delay to ~15 secs
2. fix weather group local now channel streaming error after 5 mins

#### enhancement

1. auth fallback on auth0 server down
