#! /bin/bash
### package app and load into a roku device

# Get device ip and password from `roku_ip_dev` file
DEV_FILE_CONFIG=(`cat roku_ip_dev`)

ROKU_DEV_TARGET=${DEV_FILE_CONFIG[0]}
DEVICE_PASS=${DEV_FILE_CONFIG[1]}

if [ $# -gt 0 ]; then
    ROKU_DEV_TARGET=$1
    if [ "$1" == "-h" ]; then
        echo "Usage: ./install.sh [roku_device_ip] [device_password]"
        echo "Or: config device ip and password in roku_ip_dev file"
        echo "Example format: 10.10.15.333 1234"
        exit 0
    fi
fi    

if [ $# -gt 1 ]; then
    DEVICE_PASS=$2
fi   

if [ -z "$ROKU_DEV_TARGET" ] || [ -z "$DEVICE_PASS" ]; then
    echo "ip or pass not configured in roku_ip_dev file or passed in command line."
    exit 1
fi    

# ensure package content update
touch timestamp
# packaging
echo "packing..."
zip -FS -9 -r out/fuboTV.zip components csfake images manifest mitmproxy-ca-cert.pem resource source timestamp > /dev/null
# deploy
echo "installing to $ROKU_DEV_TARGET..."
curl -f -sS --user rokudev:$DEVICE_PASS --anyauth -F "mysubmit=Install" -F "archive=@out/fuboTV.zip" -F "passwd=" http://$ROKU_DEV_TARGET/plugin_install \
     | python -c 'import sys, re; print "\n".join(re.findall("<font color=\"red\">(.*?)</font>", sys.stdin.read(), re.DOTALL))'

