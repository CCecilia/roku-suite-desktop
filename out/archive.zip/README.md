# Roku App

Please check the following information when you start working on this project

## Writing Code

### IDE

Roku has a plugin for Eclipse which supports brightscript language syntax, deploying to roku device and in IDE debug console. check [here](https://sdkdocs.roku.com/display/sdkdoc/Roku+Plugin+for+Eclipse+IDE) for detail.

If you prefer some light weight IDE for coding, [VSCODE](https://code.visualstudio.com/) is a choice, it supports brighgtscript syntax hightlighting.

### Style Guidelines

Due to the limited scripting environments on roku development, we should be consistent and inherent on code styles so the codebase is clean and maintainable.

1. Tab Width: use 4 spaces as the majority of the code does
2. Do not use extra brackets, like:
```
if (a > b)
end if
```
3. Provide comments for code that has complicated logic
4. Clean logs after finishing debug functions, we should only keep the minimum important logs in console.
5. Keep each `brs` file under 400 lines of code, otherwise modulize the component

### Pitfalls

1. Some legacy functions and components can not be directly used in scene graph components. Refer to [brightscript support](https://sdkdocs.roku.com/display/sdkdoc/BrightScript+Support) for more detail info. But be aware that the doc is not completely accurate. There's even inconsistencies between different roku os versions. You should always test on different os versions.

2. Add/Set fields in global/sg component scope is not like normal function scope. The global scope is not a simple associate array, but rather extends from `sgNode` that requires interface definition. You should create the field (set up the interface for sg component) first to manipulate the field. And the field assignment are always passed by values instead of by reference. So change any children node in field requires to reassignment to the scope.

~~This will not work consistently~~

```
m.global.xyz = { m: "kk" }
```

**This will always work**

```
if m.global.xyz = invalid
    m.global.addFields({"xyz": { m: "kk" }})
else
    m.global.xyz = { m: "kk" }
end if
```

~~This will not work~~

```
m.global.arrayA.pop()
m.global.xyz.m = "k"
```

**This will work**

```
arrayA = m.global.arrayA
arrayA.pop()
m.global.arrayA = arrayA

xyz = m.global.xyz
xyz.m = "k"
m.global.xyz = xyz
```

~~This will not work~~

```
assocArray = m.top.someFields
assocArray.x = "s"
```

**This will work**

```
assocArray = m.top.someFields
assocArray.x = "s"
m.top.someFields = assocArray
```

3. Sometimes `component.setFocus(true)` does not work as expected. It seems that roku UI framework does not guarantee the `focus` point being sucessfully set on customized component if the component hasn't been fully rendered (including its children nodes). This is very dirty.

### UI OO Hierachy


#### Screens

                   BaseScreen
                     /    \
                    /      \
                   /        \
    [SpecificScreens...] BaseScreenWithMenu
                            /    \
                           /      \
                          /        \
           [SpecificScreens...]  BaseHomeScreen
                                       \
                                        \
                                         \
                      SportsHomeScreen, SeriesHomeScreen, MoviesHomeScreen



                          BaseModal
                               \
                                \
                                 \
                           [SpecificModals...]


#### UI Components

Containers:

```
Carousel, BaseList, CategoryGrid
```

Buttons:

```
SlidingButton <- SlidingRectangle <- AnimationRectangle
ResizingButton <- BaseButton
DropdownButton
```

Players:

```
                    BasePlayer
                     /    \
                    /      \
                   /        \
               LivePlayer  VodPlayer
                            
```

Animations:

```
AnimationLabel, AnimationPoster, AnimationRectangle
```

KeyBoards:

```
BaseKeyBoard { KeyboardButton ... }
```

                   BaseKeyBoard
                     /    \
                    /      \
                   /        \
         SearchKeyBoard  AuthKeyBoard
                   
                    

### Code Merge

* PR should be reviewed by developer himself first and then reviewed by peer engineer before merge based on the logic correctness and style guidelines.
* Minor feature or bug fixes PR should increment `build_version` in [manifest](manifest)
* Major feature PR should increment `minor_version`
* `major_version` should be updated when there's whole UI or function changes in the app 

## Build

### Branching

Using simplified [git flow](https://datasift.github.io/gitflow/IntroducingGitFlow.html), taking `master` branch as developing branch. Release branches should be cut from master branch and named `release-YYYY-MM-DD`. Making merges between `master` and `release-*` branches is against the normal flow.

**Before each release cut**

1.  make sure the version info is updated in [manifest](manifest)
2.  make sure version info for install and update guide screen config is correct in [config](components/app/Interstitials/install_update/config.brs)
3.  log release changes in [release log](RELEASE.md)



### Credential

Please use the following password and device id to package the app
```
	Password: 6sz1qFZT9zVaiCxRznyJEw==
	DevID: 6472adf2beabbdeb7f27551d14603f93fca50d45
```

## QA 

### Switch Env for testing

The App is built with realtime environment switchable for sideloaded and fuboTVQA channel. It defaults to use `QA` env, for testing on `PROD` env:

1.  go to welcome screen.
2.	press **⇩** (down) button **3** times on remote controller.
3.  press `PROD` button.
4.  `QA` disappears in screen top-left corner

### Spoof Location Info

1.  go to setting screen.
2.	press **\*** (options) button **3** times on remote controller.


The channel `fuboTV QA Build` on roku store is used for QA team for testing. Any release version should be uploaded to this channel

### Deep Linking

#### General Param Format

The app accepts both `tmsId` and `airingId` for matching deep linking content. As our content is alwasy shifting by time, to faciliate roku testing, the app will always deep linking to the following content id pattern:

1.  *mediaType*=`episode`, *contentId*=`^EP(\d){5,}$`
2.  *mediaType*=`special`, *contentId*=`^SP(\d){5,}$`
3.  *mediaType*=`movie`, *contentId*=`^MV(\d){5,}$`

If the last digit of contentId equals `1`, it deep links the first promoted content, if it equals `3`, it deep links to first live content, otherwise it deep links first recent content

For `live`, `season` and `series` deeplink content, using the following params specifications:

1.  *mediaType*=`live`, *contentId*=`{networkId}_{stationId}`
2.  *mediaType*=`season`, *contentId*=`{seriesId}`
3.  *mediaType*=`series`, *contentId*=`{seriesId}`


#### Testing

Use [Online Test Tool](https://devtools.web.roku.com/DeepLinkingTester/) to launch the `dev` channel. Test cases can be uploaded [Example Cases](deeplinkTestCases.json)

## Docs And API

1. [Brightscript Language](https://sdkdocs.roku.com/display/sdkdoc/BrightScript+Language+Reference)
2. [SceneGraph Concept](https://sdkdocs.roku.com/display/sdkdoc/SceneGraph+Core+Concepts)
3. [Debugging Roku](https://sdkdocs.roku.com/display/sdkdoc/Debugging+Your+Application)
4. [Roku Devices Specs](https://sdkdocs.roku.com/display/sdkdoc/The+Roku+Channel+Developer+Program)

## Useful RC codes

*  Dump Core: **Home 5x, Up, Rew 2x, FF 2x**
*  Debug Info on screen: **Home 5x, Rew 3x, FF 2x**
*  Channel Version Info: **Home 3x, Up 2x, Left, Right, Left, Right, Left**
*  Developer Settings Page: **Home 3x, Up 2x, Right, Left, Right, Left, Right**
